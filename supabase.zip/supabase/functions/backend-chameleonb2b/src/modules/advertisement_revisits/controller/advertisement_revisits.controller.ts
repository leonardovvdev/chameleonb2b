import { AppError, json } from "../../../shared/http.ts";
import { registerAdvertisementRevisit } from "../services/advertisement_revisits.service.ts";

/** Lee y valida ?cust_id=1 de la URL. */
function parseCustId(req: Request): number {
  const raw = new URL(req.url).searchParams.get("cust_id");
  const custId = Number(raw);
  if (!raw || !Number.isSafeInteger(custId) || custId <= 0) {
    throw new AppError(400, "El cust_id no es válido.", "INVALID_CUSTOMER_ID");
  }
  return custId;
}

/** POST /advertisement-revisits?cust_id=1 → { ok: true }  (público) */
export async function registerAdvertisementRevisitHandler(req: Request): Promise<Response> {
  await registerAdvertisementRevisit(parseCustId(req));
  return json({ ok: true }, 201);
}