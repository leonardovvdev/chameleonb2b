import { AppError } from "../../../shared/http.ts";
import { supabaseAdmin } from "../../../shared/supabase.ts";

/** Suma 1 a las re-visitas del anuncio de HOY (hora de Lima) del customer indicado. */
export async function registerAdvertisementRevisit(custId: number): Promise<void> {
  const { error } = await supabaseAdmin.rpc("register_advertisement_revisit", {
    p_cust_id: custId,
  });

  if (error) {
    // 23503 = foreign key violation → el cust_id no existe en customers
    if (error.code === "23503") {
      throw new AppError(404, "La tienda no existe.", "CUSTOMER_NOT_FOUND");
    }
    console.error("advertisement_revisits.register:", error);
    throw new AppError(500, "No se pudo registrar el conteo del anuncio.");
  }
}