import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { createSignedUrls } from "../buckets/buckets.services.ts";
import type { Category, CategoryItem } from "./categories.types.ts";

const TABLE = "categories";
const COLUMNS = "ctgry_id, cust_id, ctgry_name, ctgry_name_img_link, ctgry_important";

/** Carpeta dentro del bucket del customer: {cust_name_bucket}/storage/categorias/ */
const CATEGORIES_FOLDER = "storage/categorias";
const imagePath = (fileName: string) => `${CATEGORIES_FOLDER}/${fileName}`;

/** Nombre del bucket del customer (cust_name_bucket). null si el customer no existe. */
async function getBucketName(custId: number): Promise<string | null> {
  const { data, error } = await supabaseAdmin
    .from("customers")
    .select("cust_name_bucket")
    .eq("cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("categories.getBucketName:", error);
    throw new AppError(500, "No se pudo consultar la tienda.");
  }
  return data ? String(data.cust_name_bucket) : null;
}

/** Categorías del customer: primero las importantes, luego por nombre. */
export async function listCategories(custId: number): Promise<CategoryItem[]> {
  const bucketName = await getBucketName(custId);
  if (!bucketName) {
    throw new AppError(404, "La tienda no existe.", "CUSTOMER_NOT_FOUND");
  }

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(COLUMNS)
    .eq("cust_id", custId)
    .order("ctgry_important", { ascending: false })
    .order("ctgry_name", { ascending: true });

  if (error) {
    console.error("categories.listCategories:", error);
    throw new AppError(500, "No se pudieron cargar las categorías.");
  }

  const rows = (data ?? []) as Category[];
  const withImage = rows.filter((r) => r.ctgry_name_img_link);
  const urls = await createSignedUrls(
    bucketName,
    withImage.map((r) => imagePath(r.ctgry_name_img_link as string)),
  );

  return rows.map((row) => ({
    ...row,
    img_url: row.ctgry_name_img_link
      ? urls.get(imagePath(row.ctgry_name_img_link)) ?? null
      : null,
  }));
}