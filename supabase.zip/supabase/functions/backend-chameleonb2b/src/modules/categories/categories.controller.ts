import { AppError, json } from "../../shared/http.ts";
import { listCategories } from "./categories.services.ts";

/** Lee y valida ?cust_id=1 de la URL. */
function parseCustId(req: Request): number {
  const raw = new URL(req.url).searchParams.get("cust_id");
  const custId = Number(raw);
  if (!raw || !Number.isSafeInteger(custId) || custId <= 0) {
    throw new AppError(400, "El cust_id no es válido.", "INVALID_CUSTOMER_ID");
  }
  return custId;
}

/** GET /categories?cust_id=1 → { items }  (público: es la vitrina de la tienda, no exige sesión) */
export async function listCategoriesHandler(req: Request): Promise<Response> {
  return json({ items: await listCategories(parseCustId(req)) });
}