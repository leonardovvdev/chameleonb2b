import { json } from "../../shared/http.ts";
import { resolveCustId } from "../auth/auth.services.ts";
import { listCategories } from "./categories.services.ts";

/** GET /categories[?cust_id=1] → { items }  (con ?cust_id es público; sin él, usa el JWT de la sesión) */
export async function listCategoriesHandler(req: Request): Promise<Response> {
  return json({ items: await listCategories(await resolveCustId(req)) });
}