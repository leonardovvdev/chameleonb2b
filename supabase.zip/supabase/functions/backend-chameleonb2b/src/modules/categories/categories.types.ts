export interface Category {
  ctgry_id: number;
  cust_id: number;
  ctgry_name: string;
  ctgry_name_img_link: string | null;
  ctgry_important: boolean;
}

/** Categoría lista para la tienda: incluye el enlace firmado de la imagen. */
export interface CategoryItem extends Category {
  img_url: string | null;
}