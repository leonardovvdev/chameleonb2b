import { json } from "../../shared/http.ts";
import { getAccessContext } from "../auth/auth.services.ts";
import { listActiveModuleNames } from "./customer-modules.services.ts";

/** GET /customer-modules → nombres de los módulos activos del customer de la sesión (dueño o personal). */
export async function listMyModulesHandler(req: Request): Promise<Response> {
  const ctx = await getAccessContext(req);
  return json({ modules: await listActiveModuleNames(ctx.custId) });
}