import { AppError, json } from "../../../shared/http.ts";
import { registerAdvertisementView } from "../services/advertisement_views.service.ts";

/** Lee y valida ?cust_id=1 de la URL. */
function parseCustId(req: Request): number {
  const raw = new URL(req.url).searchParams.get("cust_id");
  const custId = Number(raw);
  if (!raw || !Number.isSafeInteger(custId) || custId <= 0) {
    throw new AppError(400, "El cust_id no es válido.", "INVALID_CUSTOMER_ID");
  }
  return custId;
}

/** POST /advertisement-views?cust_id=1 → { ok: true }  (público) */
export async function registerAdvertisementViewHandler(req: Request): Promise<Response> {
  await registerAdvertisementView(parseCustId(req));
  return json({ ok: true }, 201);
}