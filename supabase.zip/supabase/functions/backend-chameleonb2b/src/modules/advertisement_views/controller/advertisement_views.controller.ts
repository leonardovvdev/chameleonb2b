import { AppError, json } from "../../../shared/http.ts";
import { findCustomerForUser, requireUser } from "../../auth/auth.services.ts";
import { listAdvertisementRevisits } from "../../advertisement_revisits/services/advertisement_revisits.service.ts";
import {
  buildAdvertisementSummary,
  listAdvertisementViews,
  registerAdvertisementView,
  summaryRange,
  todayLima,
} from "../services/advertisement_views.service.ts";

/** Lee y valida ?cust_id=1 de la URL. */
function parseCustId(req: Request): number {
  const raw = new URL(req.url).searchParams.get("cust_id");
  const custId = Number(raw);
  if (!raw || !Number.isSafeInteger(custId) || custId <= 0) {
    throw new AppError(400, "El cust_id no es válido.", "INVALID_CUSTOMER_ID");
  }
  return custId;
}

/** POST /advertisement-views?cust_id=1 → { ok: true }  (público) */
export async function registerAdvertisementViewHandler(req: Request): Promise<Response> {
  await registerAdvertisementView(parseCustId(req));
  return json({ ok: true }, 201);
}

/**
 * GET /advertisement-summary → { mes, anio, dia }  (requiere sesión)
 * Cada periodo trae { visitas, revisualizaciones, serie[] } con las vistas y re-visitas del anuncio.
 */
export async function getAdvertisementSummaryHandler(req: Request): Promise<Response> {
  const user = await requireUser(req);
  const customer = await findCustomerForUser(user);
  if (!customer) {
    throw new AppError(404, "Esta cuenta no está registrada.", "CUSTOMER_NOT_FOUND");
  }

  const today = todayLima();
  const { from, to } = summaryRange(today);
  const [views, revisits] = await Promise.all([
    listAdvertisementViews(customer.cust_id, from, to),
    listAdvertisementRevisits(customer.cust_id, from, to),
  ]);

  return json(buildAdvertisementSummary(views, revisits, today));
}
