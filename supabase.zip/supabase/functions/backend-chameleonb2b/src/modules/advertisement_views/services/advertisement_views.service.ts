import { AppError } from "../../../shared/http.ts";
import { supabaseAdmin } from "../../../shared/supabase.ts";

/** Suma 1 a las vistas del anuncio de HOY (hora de Lima) del customer indicado. */
export async function registerAdvertisementView(custId: number): Promise<void> {
  const { error } = await supabaseAdmin.rpc("register_advertisement_view", {
    p_cust_id: custId,
  });

  if (error) {
    // 23503 = foreign key violation → el cust_id no existe en customers
    if (error.code === "23503") {
      throw new AppError(404, "La tienda no existe.", "CUSTOMER_NOT_FOUND");
    }
    console.error("advertisement_views.register:", error);
    throw new AppError(500, "No se pudo registrar el conteo del anuncio.");
  }
}

/* ───────────────────────── Lectura para el summary ───────────────────────── */

export interface DailyCount {
  date: string; // YYYY-MM-DD (hora de Lima)
  total: number;
}

export interface SummaryPoint {
  etiqueta: string;
  visitas: number;
  revisualizaciones: number;
}

export interface SummaryPeriod {
  visitas: number;
  revisualizaciones: number;
  serie: SummaryPoint[];
}

export interface AdvertisementSummary {
  mes: SummaryPeriod; // total del mes, en 4 semanas
  anio: SummaryPeriod; // total del año, en 12 meses
  dia: SummaryPeriod; // total de hoy, con la semana lunes-domingo
}

const MESES = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];
const DIAS = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"];

const fechaLima = new Intl.DateTimeFormat("en-CA", {
  timeZone: "America/Lima",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});

/** Fecha de hoy en Lima (YYYY-MM-DD). */
export const todayLima = (): string => fechaLima.format(new Date());

/** Rango a consultar: todo el año actual + los bordes de la primera y la última semana. */
export function summaryRange(today: string): { from: string; to: string } {
  const year = Number(today.slice(0, 4));
  return { from: `${year - 1}-12-20`, to: `${year + 1}-01-10` };
}

/**
 * Detecta qué columna es la fecha y cuál es el contador a partir de una fila de ejemplo.
 * (fecha = texto YYYY-MM-DD; contador = primer número que no sea un id)
 */
function detectColumns(row: Record<string, unknown>): { date: string; count: string } | null {
  const entries = Object.entries(row);
  const isDate = ([, v]: [string, unknown]) => typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v);
  const isStamp = ([k, v]: [string, unknown]) =>
    typeof v === "string" && /^\d{4}-\d{2}-\d{2}T/.test(v) && !/created|updated/i.test(k);

  const date = (entries.find(isDate) ?? entries.find(isStamp))?.[0];
  const count = entries.find(
    ([k, v]) => typeof v === "number" && k !== "cust_id" && !/(^|_)id$/i.test(k),
  )?.[0];

  return date && count ? { date, count } : null;
}

/** Conteos por día de una tabla de anuncios (advertisement_views / advertisement_revisits). */
export async function listDailyCounts(
  table: string,
  custId: number,
  from: string,
  to: string,
): Promise<DailyCount[]> {
  const probe = await supabaseAdmin.from(table).select("*").eq("cust_id", custId).limit(1);
  if (probe.error) {
    console.error(`${table}.probe:`, probe.error);
    throw new AppError(500, "No se pudo consultar el conteo del anuncio.");
  }

  const sample = probe.data?.[0] as Record<string, unknown> | undefined;
  if (!sample) return []; // la tienda aún no tiene conteos

  const cols = detectColumns(sample);
  if (!cols) {
    console.error(`${table}: no se pudo detectar la columna de fecha/contador`, Object.keys(sample));
    throw new AppError(500, "No se pudo consultar el conteo del anuncio.");
  }

  // Si la columna es timestamp, el límite superior debe cubrir todo el último día.
  const upper = String(sample[cols.date]).length > 10 ? `${to}T23:59:59.999` : to;

  const { data, error } = await supabaseAdmin
    .from(table)
    .select(`${cols.date}, ${cols.count}`)
    .eq("cust_id", custId)
    .gte(cols.date, from)
    .lte(cols.date, upper);

  if (error) {
    console.error(`${table}.list:`, error);
    throw new AppError(500, "No se pudo consultar el conteo del anuncio.");
  }

  return ((data ?? []) as unknown as Record<string, unknown>[]).map((row) => ({
    date: String(row[cols.date]).slice(0, 10),
    total: Number(row[cols.count]) || 0,
  }));
}

/** Vistas del anuncio por día del customer. */
export function listAdvertisementViews(custId: number, from: string, to: string) {
  return listDailyCounts("advertisement_views", custId, from, to);
}

const toMap = (rows: DailyCount[]) => {
  const map = new Map<string, number>();
  for (const r of rows) map.set(r.date, (map.get(r.date) ?? 0) + r.total);
  return map;
};

const sumField = (serie: SummaryPoint[], field: "visitas" | "revisualizaciones") =>
  serie.reduce((acc, p) => acc + p[field], 0);

/** Arma lo que pinta el summary: mes (4 semanas), año (12 meses) y hoy (semana lun-dom). */
export function buildAdvertisementSummary(
  views: DailyCount[],
  revisits: DailyCount[],
  today: string,
): AdvertisementSummary {
  const v = toMap(views);
  const r = toMap(revisits);

  const vacio = (etiquetas: string[]): SummaryPoint[] =>
    etiquetas.map((etiqueta) => ({ etiqueta, visitas: 0, revisualizaciones: 0 }));

  const mes = vacio(["Sem 1", "Sem 2", "Sem 3", "Sem 4"]);
  const anio = vacio(MESES);

  const yearPrefix = today.slice(0, 4);
  const monthPrefix = today.slice(0, 7);

  for (const date of new Set([...v.keys(), ...r.keys()])) {
    const vis = v.get(date) ?? 0;
    const rev = r.get(date) ?? 0;

    if (date.startsWith(yearPrefix)) {
      const punto = anio[Number(date.slice(5, 7)) - 1];
      punto.visitas += vis;
      punto.revisualizaciones += rev;
    }
    if (date.startsWith(monthPrefix)) {
      // Sem 1 = días 1-7, Sem 2 = 8-14, Sem 3 = 15-21, Sem 4 = 22 en adelante
      const punto = mes[Math.min(3, Math.floor((Number(date.slice(8, 10)) - 1) / 7))];
      punto.visitas += vis;
      punto.revisualizaciones += rev;
    }
  }

  // Semana de lunes a domingo que contiene hoy
  const [year, month, day] = today.split("-").map(Number);
  const hoyMs = Date.UTC(year, month - 1, day);
  const posHoy = (new Date(hoyMs).getUTCDay() + 6) % 7; // lunes = 0
  const dia: SummaryPoint[] = DIAS.map((etiqueta, i) => {
    const date = new Date(hoyMs + (i - posHoy) * 86_400_000).toISOString().slice(0, 10);
    return { etiqueta, visitas: v.get(date) ?? 0, revisualizaciones: r.get(date) ?? 0 };
  });

  return {
    mes: { visitas: sumField(mes, "visitas"), revisualizaciones: sumField(mes, "revisualizaciones"), serie: mes },
    anio: { visitas: sumField(anio, "visitas"), revisualizaciones: sumField(anio, "revisualizaciones"), serie: anio },
    dia: { visitas: dia[posHoy].visitas, revisualizaciones: dia[posHoy].revisualizaciones, serie: dia },
  };
}
