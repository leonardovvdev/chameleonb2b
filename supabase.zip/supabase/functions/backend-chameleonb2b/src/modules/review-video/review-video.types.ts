export interface ViewWeb {
  vw_id: number;
  vw_count: number;
  vw_date: string;
}