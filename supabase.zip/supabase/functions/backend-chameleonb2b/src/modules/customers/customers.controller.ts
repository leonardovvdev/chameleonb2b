import { AppError, json } from "../../shared/http.ts";
import { findCustomerForUser, findStaffByAuthId, requireUser } from "../auth/auth.services.ts";
import { getCustomerImageUrl, getStaffImageUrl } from "../buckets/buckets.services.ts";

/**
 * GET /customers/me → datos del customer de la sesión (+ foto firmada).
 * Si quien entró es un personal (no el dueño), agrega `staff` con su nombre y su foto firmada.
 */
export async function getMeHandler(req: Request): Promise<Response> {
  const user = await requireUser(req);
  const customer = await findCustomerForUser(user);
  if (!customer) {
    throw new AppError(404, "Esta cuenta no está registrada.", "CUSTOMER_NOT_FOUND");
  }

  const imgUrl = await getCustomerImageUrl(
    String(customer.cust_name_bucket),
    customer.cust_name_img_link,
  );

  // El dueño no está en `staffs`: solo se busca cuando entra un personal.
  const staff = customer.cust_auth_id === user.id ? null : await findStaffByAuthId(user.id);
  const staffImgUrl = staff
    ? await getStaffImageUrl(String(customer.cust_name_bucket), staff.stff_link_img)
    : null;

  return json({
    cust_id: customer.cust_id,
    cust_name: customer.cust_name,
    cust_lastname: customer.cust_lastname,
    cust_name_bucket: customer.cust_name_bucket,
    cust_name_img_link: customer.cust_name_img_link,
    cust_name_img_url: imgUrl,
    staff: staff ? { ...staff, img_url: staffImgUrl } : null,
  });
}