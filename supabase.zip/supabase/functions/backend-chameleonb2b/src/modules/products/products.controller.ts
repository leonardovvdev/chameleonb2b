import { AppError, json } from "../../shared/http.ts";
import { getAccessContext, resolveCustId } from "../auth/auth.services.ts";
import {
  createProduct,
  deleteProduct,
  listProducts,
  MAX_IMAGE_BYTES,
  updateProduct,
} from "./products.services.ts";
import type { ProductInput } from "./products.types.ts";

const MAX_LIMIT = 100;

/** Entero positivo opcional (?ctgry_id=, ?limit=). undefined si no viene. */
function parseOptionalPositiveInt(req: Request, name: string, code: string): number | undefined {
  const raw = new URL(req.url).searchParams.get(name);
  if (raw === null || raw === "") return undefined;
  const value = Number(raw);
  if (!Number.isSafeInteger(value) || value <= 0) {
    throw new AppError(400, `El parámetro ${name} no es válido.`, code);
  }
  return value;
}

/**
 * GET /products[?cust_id=1][&ctgry_id=2][&limit=15] → { items }
 * (con ?cust_id es público: vitrina de la tienda; sin él, usa el JWT de la sesión)
 */
export async function listProductsHandler(req: Request): Promise<Response> {
  const custId = await resolveCustId(req);
  const ctgryId = parseOptionalPositiveInt(req, "ctgry_id", "INVALID_CATEGORY_ID");
  const limit = parseOptionalPositiveInt(req, "limit", "INVALID_LIMIT");

  return json({
    items: await listProducts(custId, {
      ctgryId,
      limit: limit !== undefined ? Math.min(limit, MAX_LIMIT) : undefined,
    }),
  });
}
const MAX_NAME_LENGTH = 200;
const MAX_PRICE = 99_999_999.99; // NUMERIC(10,2)

/** Lee y valida ?id=123 de la URL. */
function parseId(req: Request): number {
  const raw = new URL(req.url).searchParams.get("id");
  const id = Number(raw);
  if (!raw || !Number.isSafeInteger(id) || id <= 0) {
    throw new AppError(400, "El id del producto no es válido.", "INVALID_ID");
  }
  return id;
}

/** Id opcional del formulario: vacío = null (sin categoría/marca). */
function parseOptionalId(raw: FormDataEntryValue | null, message: string, code: string): number | null {
  const text = String(raw ?? "").trim();
  if (text === "") return null;
  const value = Number(text);
  if (!Number.isSafeInteger(value) || value <= 0) throw new AppError(400, message, code);
  return value;
}

/** Lee el multipart: name, price, important, ctgry_id, brnd_id y file (opcional). */
async function readForm(req: Request): Promise<{ input: ProductInput; file: File | null }> {
  const declared = Number(req.headers.get("content-length") ?? 0);
  if (declared > MAX_IMAGE_BYTES + 1024 * 100) {
    throw new AppError(400, "La imagen no puede pesar más de 5 MB.", "IMAGE_TOO_LARGE");
  }

  const form = await req.formData().catch(() => null);
  if (!form) throw new AppError(400, "El cuerpo de la petición no es válido.", "INVALID_BODY");

  const name = String(form.get("name") ?? "").trim();
  if (!name) throw new AppError(400, "El nombre del producto es obligatorio.", "NAME_REQUIRED");
  if (name.length > MAX_NAME_LENGTH) {
    throw new AppError(400, `El nombre no puede superar los ${MAX_NAME_LENGTH} caracteres.`, "NAME_TOO_LONG");
  }

  // Precio vacío = 0 (mismo DEFAULT que la tabla)
  const rawPrice = String(form.get("price") ?? "").trim().replace(",", ".");
  const price = rawPrice === "" ? 0 : Number(rawPrice);
  if (!Number.isFinite(price) || price < 0 || price > MAX_PRICE) {
    throw new AppError(400, "El precio no es válido.", "INVALID_PRICE");
  }

  const rawFile = form.get("file");
  const file = rawFile instanceof File && rawFile.size > 0 ? rawFile : null;

  return {
    input: {
      name,
      price: Math.round(price * 100) / 100,
      important: String(form.get("important") ?? "") === "true",
      ctgryId: parseOptionalId(form.get("ctgry_id"), "La categoría no es válida.", "INVALID_CATEGORY_ID"),
      brndId: parseOptionalId(form.get("brnd_id"), "La marca no es válida.", "INVALID_BRAND_ID"),
    },
    file,
  };
}

/** POST /products (multipart) → el producto creado */
export async function createProductHandler(req: Request): Promise<Response> {
  const { custId, bucketName } = await getAccessContext(req);
  const { input, file } = await readForm(req);
  return json(await createProduct(custId, bucketName, input, file), 201);
}

/** PATCH /products?id=123 (multipart) → el producto actualizado */
export async function updateProductHandler(req: Request): Promise<Response> {
  const { custId, bucketName } = await getAccessContext(req);
  const id = parseId(req);
  const { input, file } = await readForm(req);
  return json(await updateProduct(id, custId, bucketName, input, file));
}

/** DELETE /products?id=123 → { id } */
export async function deleteProductHandler(req: Request): Promise<Response> {
  const { custId, bucketName } = await getAccessContext(req);
  const id = parseId(req);
  await deleteProduct(id, custId, bucketName);
  return json({ id });
}