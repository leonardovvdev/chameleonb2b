export interface Product {
  prdct_id: number;
  ctgry_id: number | null;
  brnd_id: number | null;
  cust_id: number;
  prdct_name: string;
  prdct_name_img_link: string | null;
  prdct_important: boolean;
  prdct_price: number;
}

/** Producto listo para la tienda: incluye nombres de marca/categoría y el enlace firmado de la imagen. */
export interface ProductItem extends Product {
  brnd_name: string | null;
  ctgry_name: string | null;
  img_url: string | null;
}

/** Datos editables que llegan del formulario. */
export interface ProductInput {
  name: string;
  price: number;
  important: boolean;
  ctgryId: number | null;
  brndId: number | null;
}