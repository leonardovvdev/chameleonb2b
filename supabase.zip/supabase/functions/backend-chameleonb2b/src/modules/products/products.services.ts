import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { createSignedUrls } from "../buckets/buckets.services.ts";
import type { Product, ProductInput, ProductItem } from "./products.types.ts";
import { random11Digits } from "../../shared/random.ts";
import { convertImageToWebp } from "../../shared/convert-img-to-webp.ts";


const TABLE = "products";
const COLUMNS =
  "prdct_id, ctgry_id, brnd_id, cust_id, prdct_name, prdct_name_img_link, prdct_important, prdct_price";

/** Carpeta dentro del bucket del customer: {cust_name_bucket}/storage/productos/ */
const PRODUCTS_FOLDER = "storage/productos";
const imagePath = (fileName: string) => `${PRODUCTS_FOLDER}/${fileName}`;

/** Nombre del bucket del customer (cust_name_bucket). null si el customer no existe. */
async function getBucketName(custId: number): Promise<string | null> {
  const { data, error } = await supabaseAdmin
    .from("customers")
    .select("cust_name_bucket")
    .eq("cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("products.getBucketName:", error);
    throw new AppError(500, "No se pudo consultar la tienda.");
  }
  return data ? String(data.cust_name_bucket) : null;
}

/** Mapa id → nombre de una tabla del customer (marcas o categorías). */
async function getNames(
  table: "brands" | "categories",
  idCol: string,
  nameCol: string,
  custId: number,
): Promise<Map<number, string>> {
  const { data, error } = await supabaseAdmin
    .from(table)
    .select(`${idCol}, ${nameCol}`)
    .eq("cust_id", custId);

  if (error) {
    console.error(`products.getNames(${table}):`, error);
    throw new AppError(500, "No se pudieron cargar los productos.");
  }

  const names = new Map<number, string>();
  for (const row of (data ?? []) as Record<string, unknown>[]) {
    names.set(Number(row[idCol]), String(row[nameCol]));
  }
  return names;
}

/** Productos del customer: primero los importantes, luego por nombre. */
interface ListProductsOptions {
  ctgryId?: number; // filtra por categoría
  limit?: number;   // máximo de productos a devolver
}

/** Productos del customer: primero los importantes, luego por nombre. */
export async function listProducts(
  custId: number,
  { ctgryId, limit }: ListProductsOptions = {},
): Promise<ProductItem[]> {
  const bucketName = await getBucketName(custId);
  if (!bucketName) {
    throw new AppError(404, "La tienda no existe.", "CUSTOMER_NOT_FOUND");
  }

  let query = supabaseAdmin.from(TABLE).select(COLUMNS).eq("cust_id", custId);
  if (ctgryId !== undefined) query = query.eq("ctgry_id", ctgryId);
  query = query
    .order("prdct_important", { ascending: false })
    .order("prdct_name", { ascending: true });
  if (limit !== undefined) query = query.limit(limit);

  const [{ data, error }, brands, categories] = await Promise.all([
    query,
    getNames("brands", "brnd_id", "brnd_name", custId),
    getNames("categories", "ctgry_id", "ctgry_name", custId),
  ]);

  if (error) {
    console.error("products.listProducts:", error);
    throw new AppError(500, "No se pudieron cargar los productos.");
  }

  const rows = (data ?? []) as Product[];
  const withImage = rows.filter((r) => r.prdct_name_img_link);
  const urls = await createSignedUrls(
    bucketName,
    withImage.map((r) => imagePath(r.prdct_name_img_link as string)),
  );

  return rows.map((row) => ({
    ...row,
    brnd_name: row.brnd_id != null ? brands.get(row.brnd_id) ?? null : null,
    ctgry_name: row.ctgry_id != null ? categories.get(row.ctgry_id) ?? null : null,
    img_url: row.prdct_name_img_link
      ? urls.get(imagePath(row.prdct_name_img_link)) ?? null
      : null,
  }));
}

/* ───────────── CRUD (panel de administración) ───────────── */

const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];
const MAX_UPLOAD_ATTEMPTS = 5;
export const MAX_IMAGE_BYTES = 5 * 1024 * 1024;

function isAlreadyExists(error: { message?: string; statusCode?: string | number; status?: number }): boolean {
  return (
    String(error.statusCode ?? error.status) === "409" ||
    /already exists|duplicate/i.test(error.message ?? "")
  );
}

/** Borra una imagen del bucket. Nunca lanza error. */
async function removeImage(bucketName: string, fileName: string): Promise<void> {
  const { error } = await supabaseAdmin.storage.from(bucketName).remove([imagePath(fileName)]);
  if (error) console.error("products.removeImage:", error);
}

/** Valida, convierte a WebP y sube a {bucket}/storage/productos/. Devuelve el nombre del archivo. */
async function uploadProductImage(bucketName: string, file: File): Promise<string> {
  if (!ALLOWED_TYPES.includes(file.type)) {
    throw new AppError(400, "Formato no permitido. Usa JPG, PNG, WEBP o GIF.", "INVALID_IMAGE");
  }
  if (file.size > MAX_IMAGE_BYTES) {
    throw new AppError(400, "La imagen no puede pesar más de 5 MB.", "IMAGE_TOO_LARGE");
  }

  let webp: Uint8Array;
  try {
    webp = await convertImageToWebp(new Uint8Array(await file.arrayBuffer()));
  } catch (err) {
    console.error("products.uploadProductImage(convert):", err);
    throw new AppError(400, "No se pudo procesar la imagen. Prueba con otro archivo.", "INVALID_IMAGE");
  }

  for (let attempt = 0; attempt < MAX_UPLOAD_ATTEMPTS; attempt++) {
    const fileName = `${random11Digits()}.webp`;
    const { error } = await supabaseAdmin.storage
      .from(bucketName)
      .upload(imagePath(fileName), webp, { contentType: "image/webp", upsert: false });

    if (!error) return fileName;
    if (!isAlreadyExists(error)) {
      console.error("products.uploadProductImage(upload):", error);
      throw new AppError(500, "No se pudo subir la imagen.");
    }
  }
  throw new AppError(500, "No se pudo generar un nombre único para la imagen. Intenta de nuevo.");
}

/** Agrega nombre de marca/categoría y enlace firmado a filas sueltas. */
async function toItems(custId: number, bucketName: string, rows: Product[]): Promise<ProductItem[]> {
  const [brands, categories] = await Promise.all([
    getNames("brands", "brnd_id", "brnd_name", custId),
    getNames("categories", "ctgry_id", "ctgry_name", custId),
  ]);
  const urls = await createSignedUrls(
    bucketName,
    rows.filter((r) => r.prdct_name_img_link).map((r) => imagePath(r.prdct_name_img_link as string)),
  );
  return rows.map((row) => ({
    ...row,
    brnd_name: row.brnd_id != null ? brands.get(row.brnd_id) ?? null : null,
    ctgry_name: row.ctgry_id != null ? categories.get(row.ctgry_id) ?? null : null,
    img_url: row.prdct_name_img_link ? urls.get(imagePath(row.prdct_name_img_link)) ?? null : null,
  }));
}

/** La categoría/marca debe existir Y ser de este customer (la FK de la BD no lo garantiza). */
async function assertOwnedRef(
  table: "categories" | "brands",
  idCol: string,
  id: number | null,
  custId: number,
  message: string,
  code: string,
): Promise<void> {
  if (id === null) return;
  const { data, error } = await supabaseAdmin
    .from(table)
    .select(idCol)
    .eq(idCol, id)
    .eq("cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error(`products.assertOwnedRef(${table}):`, error);
    throw new AppError(500, "No se pudo validar la categoría o la marca.");
  }
  if (!data) throw new AppError(400, message, code);
}

async function assertRefs(custId: number, input: ProductInput): Promise<void> {
  await assertOwnedRef("categories", "ctgry_id", input.ctgryId, custId, "La categoría no existe.", "INVALID_CATEGORY_ID");
  await assertOwnedRef("brands", "brnd_id", input.brndId, custId, "La marca no existe.", "INVALID_BRAND_ID");
}

/** Producto que exista Y sea de este customer (el id llega del cliente). */
async function findOwned(id: number, custId: number): Promise<Product> {
  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .select(COLUMNS)
    .eq("prdct_id", id)
    .eq("cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("products.findOwned:", error);
    throw new AppError(500, "No se pudo consultar el producto.");
  }
  if (!data) throw new AppError(404, "El producto no existe.", "NOT_FOUND");
  return data as Product;
}

/** CREATE: la imagen es opcional. */
export async function createProduct(
  custId: number,
  bucketName: string,
  input: ProductInput,
  file: File | null,
): Promise<ProductItem> {
  await assertRefs(custId, input);
  const fileName = file ? await uploadProductImage(bucketName, file) : null;

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .insert({
      cust_id: custId,
      ctgry_id: input.ctgryId,
      brnd_id: input.brndId,
      prdct_name: input.name,
      prdct_name_img_link: fileName,
      prdct_important: input.important,
      prdct_price: input.price,
    })
    .select(COLUMNS)
    .single();

  if (error || !data) {
    console.error("products.createProduct:", error);
    if (fileName) await removeImage(bucketName, fileName); // rollback de la imagen
    throw new AppError(500, "No se pudo guardar el producto.");
  }

  const [item] = await toItems(custId, bucketName, [data as Product]);
  return item;
}

/** UPDATE: si llega imagen nueva, reemplaza la anterior. */
export async function updateProduct(
  id: number,
  custId: number,
  bucketName: string,
  input: ProductInput,
  file: File | null,
): Promise<ProductItem> {
  const current = await findOwned(id, custId);
  await assertRefs(custId, input);
  const newFileName = file ? await uploadProductImage(bucketName, file) : null;

  const { data, error } = await supabaseAdmin
    .from(TABLE)
    .update({
      ctgry_id: input.ctgryId,
      brnd_id: input.brndId,
      prdct_name: input.name,
      prdct_important: input.important,
      prdct_price: input.price,
      ...(newFileName ? { prdct_name_img_link: newFileName } : {}),
    })
    .eq("prdct_id", id)
    .eq("cust_id", custId)
    .select(COLUMNS)
    .single();

  if (error || !data) {
    console.error("products.updateProduct:", error);
    if (newFileName) await removeImage(bucketName, newFileName); // rollback de la imagen nueva
    throw new AppError(500, "No se pudo actualizar el producto.");
  }

  if (newFileName && current.prdct_name_img_link) {
    await removeImage(bucketName, current.prdct_name_img_link);
  }

  const [item] = await toItems(custId, bucketName, [data as Product]);
  return item;
}

/** DELETE: borra el producto y su imagen. */
export async function deleteProduct(id: number, custId: number, bucketName: string): Promise<void> {
  const current = await findOwned(id, custId);

  const { error } = await supabaseAdmin
    .from(TABLE)
    .delete()
    .eq("prdct_id", id)
    .eq("cust_id", custId);

  if (error) {
    console.error("products.deleteProduct:", error);
    throw new AppError(500, "No se pudo eliminar el producto.");
  }
  if (current.prdct_name_img_link) await removeImage(bucketName, current.prdct_name_img_link);
}