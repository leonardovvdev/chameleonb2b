import { json } from "../../shared/http.ts";
import { resolveCustId } from "../auth/auth.services.ts";
import { listBrands } from "./brands.services.ts";

/** GET /brands[?cust_id=1] → { items }  (con ?cust_id es público; sin él, usa el JWT de la sesión) */
export async function listBrandsHandler(req: Request): Promise<Response> {
  return json({ items: await listBrands(await resolveCustId(req)) });
}