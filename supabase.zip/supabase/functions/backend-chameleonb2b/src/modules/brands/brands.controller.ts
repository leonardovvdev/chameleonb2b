import { AppError, json } from "../../shared/http.ts";
import { listBrands } from "./brands.services.ts";

function parseCustId(req: Request): number {
  const raw = new URL(req.url).searchParams.get("cust_id");
  const custId = Number(raw);
  if (!raw || !Number.isSafeInteger(custId) || custId <= 0) {
    throw new AppError(400, "El cust_id no es válido.", "INVALID_CUSTOMER_ID");
  }
  return custId;
}

/** GET /brands?cust_id=1 → { items } */
export async function listBrandsHandler(req: Request): Promise<Response> {
  return json({ items: await listBrands(parseCustId(req)) });
}