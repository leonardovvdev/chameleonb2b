export interface Brand {
  brnd_id: number;
  brnd_name: string;
  brnd_name_img_link: string | null;
  brnd_important: boolean;
  cust_id: number;
}

export interface BrandItem extends Brand {
  img_url: string | null;
}