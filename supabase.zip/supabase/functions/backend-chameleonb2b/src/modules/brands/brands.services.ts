import { AppError } from "../../shared/http.ts";
import { supabaseAdmin } from "../../shared/supabase.ts";
import { createSignedUrls, fetchAllRows } from "../buckets/buckets.services.ts";
import type { Brand, BrandItem } from "./brands.types.ts";

const TABLE = "brands";
const COLUMNS = "brnd_id, cust_id, brnd_name, brnd_name_img_link, brnd_important";
const BRANDS_FOLDER = "storage/marcas";
const imagePath = (fileName: string) => `${BRANDS_FOLDER}/${fileName}`;

async function getBucketName(custId: number): Promise<string | null> {
  const { data, error } = await supabaseAdmin
    .from("customers")
    .select("cust_name_bucket")
    .eq("cust_id", custId)
    .maybeSingle();

  if (error) {
    console.error("brands.getBucketName:", error);
    throw new AppError(500, "No se pudo consultar la tienda.");
  }
  return data ? String(data.cust_name_bucket) : null;
}

/** Marcas del customer: primero las importantes, luego por nombre. */
export async function listBrands(custId: number): Promise<BrandItem[]> {
  const bucketName = await getBucketName(custId);
  if (!bucketName) throw new AppError(404, "La tienda no existe.", "CUSTOMER_NOT_FOUND");

  const { data, error } = await fetchAllRows<Brand>((from, to) =>
    supabaseAdmin
      .from(TABLE)
      .select(COLUMNS)
      .eq("cust_id", custId)
      .order("brnd_important", { ascending: false })
      .order("brnd_name", { ascending: true })
      .order("brnd_id", { ascending: true })
      .range(from, to)
  );

  if (error) {
    console.error("brands.listBrands:", error);
    throw new AppError(500, "No se pudieron cargar las marcas.");
  }

  const rows = (data ?? []) as Brand[];
  const urls = await createSignedUrls(
    bucketName,
    rows.filter((r) => r.brnd_name_img_link).map((r) => imagePath(r.brnd_name_img_link as string)),
  );

  return rows.map((row) => ({
    ...row,
    img_url: row.brnd_name_img_link ? urls.get(imagePath(row.brnd_name_img_link)) ?? null : null,
  }));
}