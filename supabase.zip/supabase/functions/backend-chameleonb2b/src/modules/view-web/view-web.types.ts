export interface ReviewVideo {
  rv_id: number;
  rv_count: number;
  rv_date: string;
}